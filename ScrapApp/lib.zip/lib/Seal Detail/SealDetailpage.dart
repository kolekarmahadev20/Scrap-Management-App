import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'add_seal_page.dart';
import 'edit_seal_page.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:scrapapp/AppClass/AppDrawer.dart';
import 'package:scrapapp/AppClass/appBar.dart';
import '../URL_CONSTANT.dart';

class SealDataScreen extends StatefulWidget {
  final int currentPage;
  SealDataScreen({required this.currentPage});

  @override
  _SealDataScreenState createState() => _SealDataScreenState();
}

class _SealDataScreenState extends State<SealDataScreen> {
  List<dynamic> allSealData = [];
  List<dynamic> sealData = [];
  bool isLoading = true;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchSealData(); // load all data
  }

  Future<void> fetchSealData() async {
    setState(() => isLoading = true);

    // 🔹 Read saved login credentials
    final prefs = await SharedPreferences.getInstance();
    final uuid = prefs.getString("uuid") ?? "";
    final userId = prefs.getString("username") ?? "";
    final password = prefs.getString("password") ?? "";
    final userType = prefs.getString("userType") ?? "";

    print("🔑 Using credentials:");
    print(
        "uuid=$uuid, userId=$userId, user_pass=$password, userType=$userType");

    final url = Uri.parse("${URL}get_seal_data");

    final response = await http.post(url, body: {
      "uuid": uuid,
      "user_id": userId,
      "user_pass": password,
      "user_type": userType,
      // "report_date": "2025-09-17",   // 👈 static date
    });

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      if (data["status"] == "1") {
        setState(() {
          allSealData = data["seal_data"] ?? [];
          sealData = allSealData;
          isLoading = false;
        });
      } else {
        setState(() {
          allSealData = [];
          sealData = [];
          isLoading = false;
        });
      }
    } else {
      setState(() => isLoading = false);
    }
  }

  Future<void> deleteSealRecord(String sealTransactionId) async {
    final prefs = await SharedPreferences.getInstance();
    final uuid = prefs.getString("uuid") ?? "";
    final userId = prefs.getString("username") ?? "";
    final password = prefs.getString("password") ?? "";
    final userType = prefs.getString("userType") ?? "";

    final url = Uri.parse("${URL}delete_seal_record");

    try {
      final response = await http.post(url, body: {
        "uuid": uuid,
        "user_id": userId,
        "user_pass": password,
        "user_type": userType,
        "id": sealTransactionId, // 👈 dynamic id
      });

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        String msg = data["msg"] ?? "Something went wrong";
        if (data["status"] == "1") {
          // ✅ Delete from local list
          setState(() {
            allSealData.removeWhere(
                (item) => item["seal_transaction_id"] == sealTransactionId);
            sealData = allSealData;
          });
        }

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(msg)),
        );
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Server error")),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Error: $e")),
      );
    }
  }

  void searchData(String query) {
    if (query.isEmpty) {
      setState(() => sealData = allSealData);
      return;
    }

    final lowerQuery = query.toLowerCase();
    final results = allSealData.where((seal) {
      return seal.entries.any((e) =>
          e.value != null &&
          e.value.toString().toLowerCase().contains(lowerQuery));
    }).toList();

    setState(() => sealData = results);
  }

  Widget buildField(String label, String? value) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label,
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            const SizedBox(height: 2),
            Text(
              value ?? "-",
              style: const TextStyle(fontSize: 13, color: Colors.black87),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildRow(int index, List<Widget> children) {
    return Container(
      color: index.isEven ? Colors.white : Colors.grey[200],
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      child: Row(children: children),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: AppDrawer(currentPage: widget.currentPage),
      appBar: CustomAppBar(),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 🔹 Title
          const Padding(
            padding: EdgeInsets.all(12.0),
            child: Text(
              "View Seals",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: Colors.black,
              ),
            ),
          ),

          // 🔍 Search Box
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: "Search Data",
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                prefixIcon: const Icon(Icons.search),
              ),
              onChanged: searchData,
              onSubmitted: searchData,
            ),
          ),

          // 🔹 Seal Data List
          Expanded(
            child: isLoading
                ? const Center(child: CircularProgressIndicator())
                : sealData.isEmpty
                    ? const Center(child: Text("No Seal Data Found"))
                    : ListView.builder(
                        itemCount: sealData.length,
                        itemBuilder: (context, index) {
                          final seal = sealData[index] as Map<String, dynamic>;
                          return Card(
                            margin: const EdgeInsets.all(10),
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                            elevation: 4,
                            child: Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Column(
                                children: [
                                  // 🔹 Header Row
                                  Container(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 6),
                                    decoration: BoxDecoration(
                                      color: Colors.blueGrey[500],
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        // Seal Number
                                        Expanded(
                                          child: Text(
                                            seal["sr_no"] ?? "",
                                            style: const TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.white,
                                            ),
                                            overflow: TextOverflow
                                                .ellipsis, // prevents overflow
                                          ),
                                        ),

                                        // Icons row
                                        Flexible(
                                          child: SingleChildScrollView(
                                            scrollDirection: Axis.horizontal,
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                (seal["pics"] != null &&
                                                        (seal["pics"] as List)
                                                            .isNotEmpty)
                                                    ? IconButton(
                                                        icon: const Icon(
                                                            Icons.image,
                                                            color:
                                                                Colors.white),
                                                        onPressed: () {
                                                          Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                              builder: (_) =>
                                                                  ImageViewPage(
                                                                pics: (seal[
                                                                        "pics"] ??
                                                                    []) as List,
                                                                currentPage: widget
                                                                    .currentPage,
                                                              ),
                                                            ),
                                                          );
                                                        },
                                                      )
                                                    : IconButton(
                                                        icon: const Icon(
                                                            Icons
                                                                .image_not_supported,
                                                            color: Colors.grey),
                                                        onPressed: () {
                                                          ScaffoldMessenger.of(
                                                                  context)
                                                              .showSnackBar(
                                                            const SnackBar(
                                                                content: Text(
                                                                    "No images available")),
                                                          );
                                                        },
                                                      ),
                                                IconButton(
                                                  icon: const Icon(Icons.edit,
                                                      color: Colors.white),
                                                  onPressed: () {
                                                    final sealId = seal[
                                                            "seal_transaction_id"]
                                                        .toString();
                                                    final imgUrls =
                                                        List<String>.from(
                                                            seal["img_url"] ??
                                                                []);
                                                    Navigator.push(
                                                      context,
                                                      MaterialPageRoute(
                                                        builder: (_) =>
                                                            EditSealPage(
                                                          currentPage: widget
                                                              .currentPage,
                                                          sealTransactionId:
                                                              sealId,
                                                          serverImages: imgUrls,
                                                        ),
                                                      ),
                                                    ).then((value) {
                                                      setState(() {
                                                        fetchSealData();
                                                      });
                                                    });
                                                  },
                                                ),
                                                IconButton(
                                                  icon: const Icon(Icons.delete,
                                                      color: Colors.white),
                                                  onPressed: () async {
                                                    final sealId = seal[
                                                            "seal_transaction_id"]
                                                        .toString();
                                                    final confirm =
                                                        await showDialog<bool>(
                                                      context: context,
                                                      builder: (ctx) =>
                                                          AlertDialog(
                                                        title: const Text(
                                                            "Confirm Delete"),
                                                        content: const Text(
                                                            "Are you sure you want to delete this record?"),
                                                        actions: [
                                                          TextButton(
                                                              onPressed: () =>
                                                                  Navigator.pop(
                                                                      ctx,
                                                                      false),
                                                              child: const Text(
                                                                  "Cancel")),
                                                          TextButton(
                                                              onPressed: () =>
                                                                  Navigator.pop(
                                                                      ctx,
                                                                      true),
                                                              child: const Text(
                                                                  "Delete")),
                                                        ],
                                                      ),
                                                    );
                                                    if (confirm == true) {
                                                      await deleteSealRecord(
                                                          sealId);
                                                    }
                                                  },
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  const SizedBox(height: 6),

                                  // 🔹 Alternating Rows
                                  buildRow(0, [
                                    buildField("Location",
                                        seal["location_name"]?.toString()),
                                    buildField(
                                        "Plant", seal["plant_name"]?.toString())
                                  ]),
                                  buildRow(1, [
                                    buildField("Material",
                                        seal["material_name"]?.toString()),
                                    buildField("Vessel",
                                        seal["vessel_name"]?.toString())
                                  ]),
                                  buildRow(2, [
                                    buildField("Start Seal No",
                                        seal["start_seal_no"]?.toString()),
                                    buildField("End Seal No",
                                        seal["end_seal_no"]?.toString())
                                  ]),
                                  buildRow(3, [
                                    buildField(
                                        "Extra Start Seal No",
                                        seal["extra_start_seal_no"]
                                            ?.toString()),
                                    buildField("Extra End Seal No",
                                        seal["extra_end_seal_no"]?.toString())
                                  ]),
                                  buildRow(4, [
                                    buildField("No of Seals",
                                        seal["no_of_seal"]?.toString()),
                                    buildField("Extra No of Seals",
                                        seal["extra_no_of_seal"]?.toString())
                                  ]),
                                  buildRow(5, [
                                    buildField("Rejected Seal",
                                        seal["rejected_seal_no"]?.toString()),
                                    buildField("New Seal",
                                        seal["new_seal_no"]?.toString())
                                  ]),
                                  buildRow(6, [
                                    buildField("Net Weight",
                                        seal["net_weight"]?.toString()),
                                    buildField("Seal Color",
                                        seal["seal_color"]?.toString())
                                  ]),
                                  buildRow(7, [
                                    buildField("Vehicle No",
                                        seal["vehicle_no"]?.toString()),
                                    buildField("Allow Slip No",
                                        seal["allow_slip_no"]?.toString())
                                  ]),
                                  buildRow(8, [
                                    buildField("Seal Date",
                                        seal["seal_date"]?.toString()),
                                  ]),
                                  buildRow(9, [
                                    buildField(
                                        "Vehicle Reached Date",
                                        seal["seal_unloading_date"]
                                            ?.toString()),
                                  ]),
                                  buildRow(10, [
                                    buildField("GPS Seal No",
                                        seal["gps_seal_no"]?.toString()),
                                  ]),
                                  buildRow(11, [
                                    buildField("Sender Remarks",
                                        seal["remarks"]?.toString()),
                                  ]),
                                  buildRow(12, [
                                    buildField("Receiver Remarks",
                                        seal["rev_remarks"]?.toString()),
                                  ]),

                                  const SizedBox(height: 12),

                                  // 🔹 View Images Button
                                  // 🔹 View Images Button
                                  // SizedBox(
                                  //   width: double.infinity,
                                  //   child: ElevatedButton(
                                  //     onPressed: () {
                                  //       Navigator.push(
                                  //         context,
                                  //         MaterialPageRoute(
                                  //           builder: (_) => ImageViewPage(
                                  //             pics: (seal["pics"] ?? []) as List,
                                  //             currentPage: widget.currentPage, // ✅ pass currentPage here
                                  //           ),
                                  //         ),
                                  //       );
                                  //     },
                                  //     child: const Text("View Images"),
                                  //   ),
                                  // )
                                ],
                              ),
                            ),
                          );
                        },
                      ),
          ),
        ],
      ),

      // 🔹 Floating Action Button (+ button)
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => AddSealPage(currentPage: widget.currentPage),
            ),
          ).then((value) {
            setState(() {
              fetchSealData();
            });
          });
        },
        child: const Icon(Icons.add),
        backgroundColor: Colors.blueGrey,
      ),
    );
  }
}

class ImageViewPage extends StatelessWidget {
  final List pics;

  const ImageViewPage({required this.pics, required int currentPage});

  // ✅ URL se timestamp extract karne ka function
  String extractTimestamp(String url) {
    // URL last segment le lo
    final filename = url.split('/').last;
    // filename me last "_" ke baad extension se pehle wala part le lo
    final parts = filename.split('_');
    if (parts.length >= 3) {
      return "${parts[1]}_${parts[2].split('.').first}";
    }
    return "";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(),
      body: pics.isEmpty
          ? const Center(child: Text("No Image Found"))
          : ListView.builder(
          itemCount: pics.length,
          itemBuilder: (context, index) {
            final timestamp = extractTimestamp(pics[index]);
            return Padding(
              padding: const EdgeInsets.all(8.0),
              child: Stack(
                children: [
                  Image.network(pics[index]),
                  Positioned(
                    bottom: 8,
                    right: 8,
                    child: Container(
                      color: Colors.black54,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 3),
                      child: Text(
                        timestamp,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          }),
    );
  }
}

