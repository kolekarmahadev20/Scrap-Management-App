
// const String URL = "http://devscrap.systementerprises.in/api/Comp_login/";
const String URL = "http://scrap.systementerprises.in/api/Comp_login/";

// const String Image_URL ='http://devscrap.systementerprises.in/';
const String Image_URL ='http://scrap.systementerprises.in/';
